

export const darkTheme = {
    background: "#121212",
    card: "#1e1e1e",
    text: "#f5f5f5",
    label: "#aaaaaa",
    border: "#444",
    buttonPrimary: "#3399ff",
    buttonDanger: "ff4d4d",
    result: "#66ccff",
    infoBg: "#1e1e1e",
    infoBorder: "#333",
   

}
