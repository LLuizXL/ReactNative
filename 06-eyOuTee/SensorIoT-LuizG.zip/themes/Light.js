
export const lightTheme = {
    background: "#f0f0f0",
    card: "#fff",
    text: "#212121",
    label: "#555",
    border: "#ccc",
    buttonPrimary: "#007bff",
    buttonDanger: "#dc3545",
    result: "#007bff",
    infoBg: "#fff",
    infoBorder: "#eee",
}